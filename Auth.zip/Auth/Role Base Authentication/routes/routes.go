package routes

import (
	"database/sql"
	"net/http"

	"github.com/gorilla/mux"

	"yourproject/controllers"
	"yourproject/middleware"
)

func SetupRoutes(db *sql.DB) *mux.Router {
	r := mux.NewRouter()

	r.HandleFunc("/register", controllers.Register(db)).Methods("POST")
	r.HandleFunc("/login", controllers.Login(db)).Methods("POST")

	admin := r.PathPrefix("/admin").Subrouter()
	admin.Use(middleware.RoleAuth("admin"))
	admin.HandleFunc("/dashboard", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Welcome Admin!"))
	})

	superadmin := r.PathPrefix("/superadmin").Subrouter()
	superadmin.Use(middleware.RoleAuth("superadmin"))
	superadmin.HandleFunc("/dashboard", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Welcome Superadmin!"))
	})

	return r
}
