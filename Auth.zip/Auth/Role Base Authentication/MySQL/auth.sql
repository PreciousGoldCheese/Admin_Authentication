-- CREATE TABLE users (
--     id BIGINT AUTO_INCREMENT PRIMARY KEY NOT NULL UNIQUE,
--     username VARCHAR(50) NOT NULL UNIQUE,
--     email VARCHAR(100) NOT NULL UNIQUE,
--     primary_phone VARCHAR(20) NULL,
--     secondary_phone VARCHAR(20) NOT NULL,
--     password VARCHAR(255) NOT NULL,
--     role ENUM('user', 'admin', 'superadmin') NOT NULL DEFAULT 'user',
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );


CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY NOT NULL UNIQUE,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    primary_phone VARCHAR(20) NULL,
    secondary_phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    role ENUM('admin', 'superadmin', 'marketing') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
