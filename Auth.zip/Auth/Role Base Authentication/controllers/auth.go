// package controllers

// import (
// 	"auth/config"
// 	"auth/models"
// 	"auth/utils"
// 	"database/sql"
// 	"encoding/json"
// 	"net/http"
// 	"regexp"

// 	"golang.org/x/crypto/bcrypt"
// )

// func Register(w http.ResponseWriter, r *http.Request) {
// 	var user models.User
// 	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
// 		http.Error(w, "Invalid request body", http.StatusBadRequest)
// 		return
// 	}

// 	if !validEmail(user.Email) || len(user.Password) < 8 || user.Username == "" {
// 		http.Error(w, "Invalid input", http.StatusBadRequest)
// 		return
// 	}

// 	// Prevent creation of superadmin via public registration
// 	if user.Role == "superadmin" {
// 		http.Error(w, "SuperAdmin creation not allowed via public endpoint", http.StatusForbidden)
// 		return
// 	}

// 	// Hash password
// 	hashed, err := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost+2)
// 	if err != nil {
// 		http.Error(w, "Password hashing failed", http.StatusInternalServerError)
// 		return
// 	}

// 	// Insert user into DB
// 	stmt, err := config.DB.Prepare("INSERT INTO users(username, email, primary_phone , password, role) VALUES(?, ?, ?, ?, ?)")
// 	if err != nil {
// 		http.Error(w, "Database error", http.StatusInternalServerError)
// 		return
// 	}
// 	defer stmt.Close()

// 	_, err = stmt.Exec(user.Username, user.Email, hashed, user.Role)
// 	if err != nil {
// 		http.Error(w, "Username or email already exists", http.StatusConflict)
// 		return
// 	}

// 	w.WriteHeader(http.StatusCreated)
// 	json.NewEncoder(w).Encode(map[string]string{"message": "Registered successfully"})
// }

// func Login(w http.ResponseWriter, r *http.Request) {
// 	var creds models.User
// 	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
// 		http.Error(w, "Invalid request body", http.StatusBadRequest)
// 		return
// 	}

// 	var dbUser models.User
// 	err := config.DB.QueryRow("SELECT username, password, role FROM users WHERE username = ?", creds.Username).
// 		Scan(&dbUser.Username, &dbUser.Password, &dbUser.Role)

// 	if err == sql.ErrNoRows || bcrypt.CompareHashAndPassword([]byte(dbUser.Password), []byte(creds.Password)) != nil {
// 		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
// 		return
// 	} else if err != nil {
// 		http.Error(w, "Database error", http.StatusInternalServerError)
// 		return
// 	}

// 	token, err := utils.GenerateJWT(dbUser.Username, dbUser.Role)
// 	if err != nil {
// 		http.Error(w, "Token generation failed", http.StatusInternalServerError)
// 		return
// 	}

// 	json.NewEncoder(w).Encode(map[string]string{"token": token})
// }

// func validEmail(email string) bool {
// 	re := regexp.MustCompile(`^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$`)
// 	return re.MatchString(email)
// }

package controllers

import (
	"database/sql"
	"encoding/json"
	"net/http"

	"yourproject/models"
	"yourproject/utils"
)

func Register(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var user models.User
		json.NewDecoder(r.Body).Decode(&user)

		// Prevent creation of superadmin via public registration
		if user.Role == "superadmin" {
			http.Error(w, "SuperAdmin creation not allowed via public endpoint", http.StatusForbidden)
			return
		}

		hashedPassword, err := utils.HashPassword(user.Password)
		if err != nil {
			http.Error(w, "Password encryption failed", http.StatusInternalServerError)
			return
		}

		_, err = db.Exec("INSERT INTO users (username, password, primary_phone, secondary_phone, email, role) VALUES (?, ?, ?, ?, ?, ?)",
			user.Username, hashedPassword, user.PrimaryPhone, user.SecondaryPhone, user.Email, user.Role)

		if err != nil {
			http.Error(w, "Registration failed", http.StatusBadRequest)
			return
		}

		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(map[string]string{"message": "User registered successfully"})
	}
}
