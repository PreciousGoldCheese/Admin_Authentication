// package config
// import (
// 	"fmt"
// 	"log"
// 	"os"
// 	"database/sql"
// 	_ "github.com/go-sql-driver/mysql"
//     "github.com/joho/godotenv"
// )

// var DB*sql.DB

// func Connect(){
// 	err := godotenv.Load()
// 	if err != nil{
// 		log.Fatal("Error Loading .env")
// 	}

// 	dsn := fmt.Sprintf("%s:%s@tcp(%s)/%s?parseTime=true",
// 	os.Getenv("DB_USER"),
// 	os.Getenv("DB_PASS"),
// 	os.Getenv("DB_HOST"),
// 	os.Getenv("DB_Name"),
// )
// DB, err = sql.Open("mysql",dsn)
// 	if err != nil{
// 		log.Fatal("Fail To Connect DB:", err)
// 	}

// 	if err = DB.Ping(); err != nil{
// 		log.Fatal("Database Unreachable:", err)
// 	}

// 	log.Println("Connect To MySQL")
// }

package config

import (
	"database/sql"
	"log"

	_ "github.com/go-sql-driver/mysql"
)

func ConnectDB() *sql.DB {
	db, err := sql.Open("mysql", "user:password@tcp(127.0.0.1:3306)/yourdb")
	if err != nil {
		log.Fatal(err)
	}
	return db
}
