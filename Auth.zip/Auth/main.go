package main

import (
	"log"
	"net/http"

	"yourproject/config"
	"yourproject/routes"
)

func main() {
	db := config.ConnectDB()
	r := routes.SetupRoutes(db)

	log.Println("Server started at :8080")
	log.Fatal(http.ListenAndServe(":8080", r))
}
